# RTDS 新增用例与回归执行记录 · 2026-10-10

远程目标：DESKTOP-H0AB0MD，工程 `C:\project\RTDS\DDR\RTDS_test_DDR4_64bit_batch_dev`。Vivado 2020.2。新增用例已执行5项，4项PASS、TC-F11 FAIL；既有10项回归全部PASS。业务RTL未修改。

| 用例 | 场景 | 结果 | 运行目录 |
|---|---|---|---|
| TC-F09 | byte1_1g | PASS | verification_20261010/functional_r2 |
| TC-F10 | tx_boundaries | PASS | verification_20261010/functional_r2 |
| TC-F12 | regs_multiblock | PASS | verification_20261010/functional_r2 |
| TC-M09 | period_100ms | PASS | verification_20261010/period_r2 |
| TC-F11 | ready_recovery | FAIL | verification_20261010/recovery_r5 |

TC-F11：Aurora及PCIe断链后CONV_DMA旧读busy残留；下一32Byte任务前两拍输出旧数据。DDR就绪中断后新任务busy不结束、无数据。失败记录6项，来自3种中断路径。测试台明确记录失败后用全局复位清理，仅为继续独立检查；复位后通过未计为恢复通过。未就绪门控、R/B SLVERR、0x2C状态、真实FIFO溢出、超时和0x10清错均完成。

TC-M09实际250MHz／25,000,000拍，仿真400.000394ms。4次周期事件，3个连续100ms间隔；空块不发布、偶数8Byte／延迟响应8Byte／奇尾4Byte的地址、数据、FF/0F字节使能与成功响应先后均检查。

## 查看波形

打开 `evidence/local_wave_sessions/index_new_cases_20261010.html`。各组有源码快照与离线三窗格查看器。也可从工程根目录执行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Open-LocalWave.ps1 -Case ready_recovery
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\Open-LocalWave.ps1 -Case period_100ms -Vivado
```

用例名：`byte1_1g`、`tx_boundaries`、`ready_recovery`、`regs_multiblock`、`period_100ms`。原七组历史波形保留；不要将旧1G二拍波形当作当前四拍格式。

100ms全程记录事件及相关接口，不记录250MHz时钟、计数器和clocking副本。其余递归记录可追踪信号；VCD不支持非打包数组，WDB亦有大小限制。“全部信号”指全部实际记录的VCD信号。代码定位是静态首个标识符位置，连接跳转指向实际父模块端口。

## 证据与复现

源码版本：各组 `source_hashes.json` + `sources/`；记录文件哈希见 `capture_manifest.json`。日志见各组 `*.simulate.log`。生产源文件与当日已审计版本一致；新增测试台在 `regression/new_cases_20261010`。集成用例采用8µs缩时接收周期，TC-M09单独使用100ms生产参数。

执行汇总：`evidence/execution_summary_20261010.json`。现有回归：`evidence/new_case_logs/regression_after_new_cases/summary.json`。回归范围为sync/1g/tx/rx_fifo/ring/axi/axi_tail/regs/board_cdc/fast_base，全部PASS。

原生Vivado打开验证与离线查看器功能检查结果同目录归档。文档仅检查DOCX压缩包/XML结构，没有渲染PDF/PNG。

## 边界与待修复

模块／行为模型通过没有扩大解释为真实XDMA Root Port、GT或板级通过；完整TOP CDC仍未通过。非零CARD_ADDR_HI历史失败保留。TC-F11需统一取消事务、旧返回排空和DDR中断后的AXI主机处理，再执行无复位恢复回归。
